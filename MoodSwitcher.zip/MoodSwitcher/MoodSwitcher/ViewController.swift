//
//  ViewController.swift
//  MoodSwitcher
//
//  Created by Alik Hamdamov on 01.06.17.
//  Copyright © 2017 Khamdamov. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {
  
  
  @IBOutlet weak var button1up: UIButton!
  
  @IBOutlet weak var button1down: UIButton!
  
  @IBOutlet weak var button2up: UIButton!
  
  @IBOutlet weak var button2down: UIButton!
  
  var soundOnPlayer: AVAudioPlayer!
  var soundOffPlayer: AVAudioPlayer!
  
  @IBOutlet weak var background: UIView!
  @IBOutlet weak var moodLabel: UILabel!
  
  var counter = 0
  

  override func viewDidLoad() {
    super.viewDidLoad()
    
    startPosition()
    setupAudioFiles()
  }
  
  func setupAudioFiles() {
    
    let soundFilePathOn = Bundle.main.path(forResource: "switchOn", ofType: "wav")
    let soundFileURLOn = NSURL(fileURLWithPath: soundFilePathOn!)
    
    let soundFilePathOff = Bundle.main.path(forResource: "switchOff", ofType: "wav")
    let soundFileURLOff = NSURL(fileURLWithPath: soundFilePathOff!)
    
    do {
      try soundOnPlayer = AVAudioPlayer(contentsOf: soundFileURLOn as URL)
      try soundOffPlayer = AVAudioPlayer(contentsOf: soundFileURLOff as URL)
    } catch {
      print(error)
    }
    
    soundOnPlayer.delegate = self
    soundOffPlayer.delegate = self
    
    soundOnPlayer.numberOfLoops = 0
    soundOffPlayer.numberOfLoops = 0
    
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }

  @IBAction func button1upPressed(_ sender: Any) {
    
    if button1up.isUserInteractionEnabled {
      soundOnPlayer.play()
      counter += 1
      button1up.setImage(UIImage(named: "button2-1"), for: .normal)
      button1down.setImage(UIImage(named: "button2-2"), for: .normal)
      button1up.isUserInteractionEnabled = false
      button1down.isUserInteractionEnabled = true
      changeBG()
    }
    
    print(counter)
  }
 
  @IBAction func button1downPressed(_ sender: Any) {
    
    if button1down.isUserInteractionEnabled {
      soundOffPlayer.play()
      counter += 1
      button1down.setImage(UIImage(named: "button1-2"), for: .normal)
      button1up.setImage(UIImage(named: "button1-1"), for: .normal)
      button1up.isUserInteractionEnabled = true
      button1down.isUserInteractionEnabled = false
      changeBG()
    }
    
    print(counter)
  }
  
  @IBAction func button2upPressed(_ sender: Any) {
    
    if button2up.isUserInteractionEnabled {
      soundOnPlayer.play()
      counter += 1
      button2up.setImage(UIImage(named: "button2-1"), for: .normal)
      button2down.setImage(UIImage(named: "button2-2"), for: .normal)
      button2up.isUserInteractionEnabled = false
      button2down.isUserInteractionEnabled = true
      changeBG()
    }
    
    print(counter)
  }
  
  @IBAction func button2downPressed(_ sender: Any) {
    
    if button2down.isUserInteractionEnabled {
      soundOffPlayer.play()
      counter += 1
      button2down.setImage(UIImage(named: "button1-2"), for: .normal)
      button2up.setImage(UIImage(named: "button1-1"), for: .normal)
      button2up.isUserInteractionEnabled = true
      button2down.isUserInteractionEnabled = false
      changeBG()
    }
    
    print(counter)
  }
  
  // MARK: Helper methods
  
  func startPosition() {
    button1down.isUserInteractionEnabled = false
    button2up.isUserInteractionEnabled = false
  }
  
  // Change background color and label
  func changeBG() {
    switch counter {
    case 1...5:
      background.backgroundColor = UIColor(red: 248/255, green: 231/255, blue: 28/255, alpha: 1.0) // yellow
      moodLabel.text = NSLocalizedString("TakeYourTime", comment: "Take your time!") //"Take your time!"
      break
    case 6...10:
      background.backgroundColor = UIColor(red: 245/255, green: 166/255, blue: 35/255, alpha: 1.0) // orange
      moodLabel.text = NSLocalizedString("AreYouCalmYet", comment: "Are you calm yet?") //"Are you calm yet?"
      break
    case 11...25:
      background.backgroundColor = UIColor(red: 79/255, green: 226/255, blue: 255/255, alpha: 1.0) // turqoise
      moodLabel.text = NSLocalizedString("Take it easy", comment: "Take it easy!") //"Take it easy!"
      break
    case 26...40:
      background.backgroundColor = UIColor(red: 34/255, green: 249/255, blue: 201/255, alpha: 1.0) // light green-ish
      moodLabel.text = NSLocalizedString("You can achieve everything!", comment: "You can achieve everything!") //"You can \n achieve \n everything!"
      break
    case 41...75:
      background.backgroundColor = UIColor(red: 80/255, green: 227/255, blue: 0/255, alpha: 1.0) // green
      moodLabel.text = NSLocalizedString("Every person is a Universe!", comment: "Every person is a Universe!") //"Every person is a Universe!"
      break
    case 76...100:
      background.backgroundColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1.0) // red
      moodLabel.text = NSLocalizedString("Smile! You are awesome!", comment: "Smile!") //"Smile! \n You are awesome!"
      break
    case 101:
      background.backgroundColor = UIColor(red: 95/255, green: 136/255, blue: 198/255, alpha: 0.4) // starting color
      moodLabel.text = NSLocalizedString("Again?!", comment: "What?! Again?") //"What?! \n Again?"
      counter = 0
      break
    default:
      break
    }
  }
  

}

